declare const queryAllBySelector: (...args: any[]) => HTMLElement[];
declare const queryBySelector: import("@testing-library/react").QueryBy<any[]>, getAllBySelector: import("@testing-library/react").GetAllBy<any[]>, getBySelector: import("@testing-library/react").GetBy<any[]>, findBySelector: import("@testing-library/react").FindAllBy<any[]>;
export { queryAllBySelector, queryBySelector, getAllBySelector, getBySelector, findBySelector };
