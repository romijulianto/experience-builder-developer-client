/** @jsx jsx */
import { jsx } from 'jimu-core';
interface Props {
    appId: string;
    isOpen: boolean;
    onClose: () => void;
}
export declare const DownloadAppModal: (props: Props) => jsx.JSX.Element;
export {};
