/** @jsx jsx */
import { jsx } from 'jimu-core';
interface Props {
    checked: boolean;
    onChange: (checked: boolean) => void;
}
export declare const ExpressModeSwitch: (props: Props) => jsx.JSX.Element;
export {};
