import { WidgetManager } from 'jimu-core';
export default class AppWidgetManager extends WidgetManager {
    static getInstance(): WidgetManager;
}
