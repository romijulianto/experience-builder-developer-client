import { type IParams } from '@esri/arcgis-rest-request';
export declare function request(url: string, requestOptions?: IParams, requestType?: 'GET' | 'POST'): Promise<any>;
