import { type IParams } from '@esri/arcgis-rest-request';
import { type AppInfo } from '../../type';
export declare function deleteThumbnail(appInfo: AppInfo, requestOptions: IParams): Promise<any>;
