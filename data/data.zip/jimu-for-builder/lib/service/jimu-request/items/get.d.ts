import { type AppInfo } from '../../type';
export declare function getDraftAppConfig(appInfo: AppInfo): Promise<any>;
