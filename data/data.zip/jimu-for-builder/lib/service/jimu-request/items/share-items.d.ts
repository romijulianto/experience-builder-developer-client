import { type IParams } from '@esri/arcgis-rest-request';
export declare function shareItems(requestOptions: IParams): Promise<any>;
