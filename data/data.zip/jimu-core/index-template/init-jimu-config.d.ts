declare function initJimuConfig(): void;
declare function getDeployContextFromLocation(): string;
