import { jsx } from '@emotion/react';
import { type DialogProps } from '../types';
declare function AnchoredDialog({ dialogJson, opener, toggle }: DialogProps): jsx.JSX.Element;
export default AnchoredDialog;
