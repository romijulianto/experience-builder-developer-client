export declare function AddMetaTag(): any;
