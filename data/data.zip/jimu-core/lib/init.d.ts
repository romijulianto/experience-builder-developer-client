/**
 * By convention the default locale must be the first.
 **/
export declare const translatedLocales: string[];
export declare function init(): Promise<void>;
