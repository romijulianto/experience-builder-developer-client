export declare function useIntersection(ref: HTMLElement, canMonitor: boolean, enableMonitor: boolean): [number, boolean];
