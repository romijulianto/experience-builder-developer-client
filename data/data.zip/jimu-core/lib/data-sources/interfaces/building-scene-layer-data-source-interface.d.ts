import { type DataSourceTypes } from './common-data-source-interface';
export interface BuildingSceneLayerDataSourceInterface {
    type: DataSourceTypes.BuildingSceneLayer;
}
