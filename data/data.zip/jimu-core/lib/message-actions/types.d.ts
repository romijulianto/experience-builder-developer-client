export declare enum MessageActionConnectionType {
    UseLayersRelationship = "USE_LAYERS_RELATIONSHIP",
    SetCustomFields = "SET_CUSTOM_FIELDS"
}
