export declare function SetDocumentTitle(): any;
